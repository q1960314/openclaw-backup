# OpenClaw 配置备份恢复指南

## 备份信息
- **备份时间**: 2026-03-20 13:17
- **备份文件**: openclaw-backup-20260320-1317.tar.gz
- **备份大小**: 13KB
- **OpenClaw 版本**: 2026.2.26 → 目标 2026.3.13

---

## 备份内容

### 核心配置
- openclaw.json - 主配置文件
- AGENTS.md, SOUL.md, USER.md 等工作区文件
- 14 个 agent 的 models.json
- memory/ 记忆文件

---

## 恢复步骤

### 1. 解压备份
```bash
tar -xzf openclaw-backup-20260320-1317.tar.gz
cd openclaw-backup-final
```

### 2. 恢复配置
```bash
cp openclaw.json /home/admin/.openclaw/
cp AGENTS.md SOUL.md USER.md TOOLS.md /home/admin/.openclaw/workspace/
cp -r memory/* /home/admin/.openclaw/workspace/memory/
for f in agent-models/*.json; do
  agent_name=$(basename $f .json)
  cp $f /home/admin/.openclaw/agents/$agent_name/agent/models.json
done
```

### 3. 重启验证
```bash
openclaw gateway restart
openclaw memory-pro stats
```

---

## 上传到 GitHub

```bash
cd /tmp
# 创建仓库或上传文件
# GitHub Web 界面上传：openclaw-backup-20260320-1317.tar.gz
```

---

**备份位置**: /tmp/openclaw-backup-20260320-1317.tar.gz (13KB)
