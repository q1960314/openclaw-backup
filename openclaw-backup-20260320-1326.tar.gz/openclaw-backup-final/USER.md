# USER.md - About Your Human

- **Name:** 90
- **What to call them:** 90
- **Pronouns:** _(optional)_
- **Timezone:** Asia/Shanghai (北京时区)
- **Notes:**

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
